﻿CREATE PROCEDURE Production.usp_LoadBuilding
AS
BEGIN
    -- Clear old data 
    DELETE FROM Production.BuildingLocation;

    INSERT INTO Production.BuildingLocation (BuildingName)
    SELECT BuildingName
    FROM Group3.fn_BuildingSource()
END
