CREATE PROCEDURE Production.usp_LoadMode
AS
BEGIN
    DELETE FROM Production.ModeOfInstruction

    INSERT INTO Production.ModeOfInstruction (ModeName)
    SELECT ModeName
    FROM Group3.fn_ModeSource()
END;
