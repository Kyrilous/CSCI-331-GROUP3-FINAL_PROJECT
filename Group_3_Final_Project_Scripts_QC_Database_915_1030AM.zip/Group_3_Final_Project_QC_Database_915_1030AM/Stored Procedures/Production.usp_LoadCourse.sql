CREATE PROCEDURE Production.usp_LoadCourse
AS
BEGIN
    -- Clear course table first
    DELETE FROM Production.Course;

    INSERT INTO Production.Course
    (
        DepartmentID, CourseNumber, Credits, CourseTitle
    )
    SELECT
        d.DepartmentID, c.CourseNumber, c.Credits, c.CourseTitle
    FROM Group3.fn_CourseSource() c
    JOIN Production.Department d
        ON d.DepartmentCode = c.DepartmentCode;
END
