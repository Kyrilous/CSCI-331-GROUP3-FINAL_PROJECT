CREATE PROCEDURE Production.usp_LoadDepartment
AS
BEGIN
    -- Start clean
    DELETE FROM Production.Department;

    -- Insert distinct departments from ITVF
    INSERT INTO Production.Department (DepartmentCode, DepartmentName)
    SELECT DepartmentCode, DepartmentName
    FROM Group3.fn_DepartmentSource()
END
