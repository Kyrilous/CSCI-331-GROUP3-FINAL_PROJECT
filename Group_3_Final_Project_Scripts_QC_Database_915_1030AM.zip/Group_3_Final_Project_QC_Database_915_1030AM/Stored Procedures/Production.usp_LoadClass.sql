CREATE PROCEDURE Production.usp_LoadClass
AS
BEGIN
    -- Clear old rows
    TRUNCATE TABLE Production.Class

    INSERT INTO Production.Class
    (
        CourseID, InstructorID, RoomID, ModeID, SemesterID, SectionNumber, Enrollment, EnrollmentLimit, ClassTime, DateAdded, DateOfLastUpdate
    )
    SELECT
        co.CourseID, i.InstructorID, r.RoomID, m.ModeID, s.SemesterID, c.SectionNumber, c.Enrollment, c.EnrollmentLimit, c.ClassTime, SYSUTCDATETIME(), SYSUTCDATETIME()
    FROM Group3.fn_ClassSource() c

    -- Course join
    JOIN Production.Course co
        ON co.CourseNumber = c.CourseNumber
    JOIN Production.Department d
        ON d.DepartmentCode = c.DepartmentCode
       AND d.DepartmentID = co.DepartmentID

    -- Instructor join
    JOIN Production.Instructor i
        ON i.FirstName = c.FirstName
       AND i.LastName  = c.LastName

    -- Room and Building join
    JOIN Production.BuildingLocation b
        ON b.BuildingName = c.BuildingName
    JOIN Production.RoomLocation r
        ON r.BuildingID = b.BuildingID
       AND r.RoomNumber = c.RoomNumber

    -- Mode join
    JOIN Production.ModeOfInstruction m
        ON m.ModeName = c.ModeName

    -- Semester join
    JOIN Production.Semester s
        ON s.SemesterName = c.SemesterName
END
