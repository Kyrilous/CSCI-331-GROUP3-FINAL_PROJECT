CREATE PROCEDURE Production.usp_LoadInstructor
AS
BEGIN
    -- Clear existing instructors
    DELETE FROM Production.Instructor;

    INSERT INTO Production.Instructor (FirstName, LastName, DepartmentID)
    SELECT 
        i.FirstName, i.LastName, d.DepartmentID
    FROM Group3.fn_InstructorSource() i
    JOIN Production.Department d
        ON d.DepartmentCode = i.DepartmentCode;
END
