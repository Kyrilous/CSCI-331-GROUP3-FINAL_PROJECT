CREATE PROCEDURE Production.usp_LoadRoom
AS
BEGIN
    -- Clear old room rows 
    DELETE FROM Production.RoomLocation;

    INSERT INTO Production.RoomLocation (BuildingID, RoomNumber)
    SELECT 
        b.BuildingID,
        r.RoomNumber
    FROM Group3.fn_RoomSource() r
    JOIN Production.BuildingLocation b
        ON b.BuildingName = r.BuildingName;
END
