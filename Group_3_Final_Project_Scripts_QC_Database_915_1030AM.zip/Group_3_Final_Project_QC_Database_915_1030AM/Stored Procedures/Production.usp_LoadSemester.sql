CREATE PROCEDURE Production.usp_LoadSemester
AS
BEGIN
    DELETE FROM Production.Semester;

    INSERT INTO Production.Semester (SemesterName)
    SELECT SemesterName
    FROM Group3.fn_SemesterSource()
END
