CREATE TABLE Production.Course
(
    CourseID Udt.SurrogateKeyInt IDENTITY(1,1) NOT NULL,
    DepartmentID Udt.SurrogateKeyInt NOT NULL,
    CourseNumber Udt.CourseNumber NOT NULL,
    CourseTitle Udt.CourseTitle NOT NULL,
    Credits Udt.Credits NOT NULL,
    DateAdded Udt.DateAdded NOT NULL,
    DateOfLastUpdate Udt.DateOfLastUpdate NOT NULL,
    CONSTRAINT PK_Course PRIMARY KEY CLUSTERED (CourseID)
;
