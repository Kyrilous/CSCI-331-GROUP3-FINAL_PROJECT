CREATE TABLE Production.BuildingLocation
(
    BuildingID Udt.SurrogateKeyInt IDENTITY(1,1) NOT NULL,
    BuildingName Udt.BuildingName NOT NULL,
    DateAdded Udt.DateAdded NOT NULL,
    DateOfLastUpdate Udt.DateOfLastUpdate NOT NULL,
    CONSTRAINT PK_BuildingLocation PRIMARY KEY CLUSTERED (BuildingID)
)
