CREATE TABLE Production.Semester
(
    SemesterID Udt.SurrogateKeyInt IDENTITY(1,1) NOT NULL,
    SemesterName Udt.SemesterName NOT NULL,
    DateAdded Udt.DateAdded NOT NULL,
    DateOfLastUpdate Udt.DateOfLastUpdate NOT NULL,
    CONSTRAINT PK_Semester PRIMARY KEY CLUSTERED (SemesterID)
)
