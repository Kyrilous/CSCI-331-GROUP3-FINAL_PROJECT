CREATE TABLE Production.Department
(
    DepartmentID Udt.SurrogateKeyInt IDENTITY(1,1) NOT NULL,
    DepartmentName Udt.DepartmentName NOT NULL,
    DepartmentCode Udt.DepartmentCode NOT NULL,
    DateAdded Udt.DateAdded NOT NULL,
    DateOfLastUpdate Udt.DateOfLastUpdate NOT NULL,
    CONSTRAINT PK_Department PRIMARY KEY CLUSTERED (DepartmentID)
)
