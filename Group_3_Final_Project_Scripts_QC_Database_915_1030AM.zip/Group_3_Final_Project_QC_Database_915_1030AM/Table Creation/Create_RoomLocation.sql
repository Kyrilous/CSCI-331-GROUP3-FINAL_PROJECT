CREATE TABLE Production.RoomLocation
(
    RoomID Udt.SurrogateKeyInt IDENTITY(1,1) NOT NULL,
    BuildingID Udt.SurrogateKeyInt NOT NULL,
    RoomNumber Udt.RoomNumber NOT NULL,
    DateAdded Udt.DateAdded NOT NULL,
    DateOfLastUpdate Udt.DateOfLastUpdate NOT NULL,
    CONSTRAINT PK_RoomLocation PRIMARY KEY CLUSTERED (RoomID)
)
