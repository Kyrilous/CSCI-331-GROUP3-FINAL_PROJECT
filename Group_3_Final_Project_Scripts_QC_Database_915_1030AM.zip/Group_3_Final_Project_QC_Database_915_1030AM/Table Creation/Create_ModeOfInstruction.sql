CREATE TABLE Production.ModeOfInstruction
(
    ModeID Udt.SurrogateKeyInt IDENTITY(1,1) NOT NULL,
    ModeName Udt.ModeName NOT NULL,
    DateAdded Udt.DateAdded NOT NULL,
    DateOfLastUpdate Udt.DateOfLastUpdate NOT NULL,
    CONSTRAINT PK_ModeOfInstruction PRIMARY KEY CLUSTERED (ModeID)
)
