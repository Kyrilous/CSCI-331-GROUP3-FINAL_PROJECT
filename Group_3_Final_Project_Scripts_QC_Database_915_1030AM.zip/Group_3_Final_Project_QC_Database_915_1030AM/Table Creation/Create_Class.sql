CREATE TABLE Production.Class
(
    ClassID Udt.SurrogateKeyInt IDENTITY(1,1) NOT NULL,
    CourseID Udt.SurrogateKeyInt NOT NULL,
    InstructorID Udt.SurrogateKeyInt NOT NULL,
    RoomID Udt.SurrogateKeyInt NOT NULL,
    ModeID Udt.SurrogateKeyInt NOT NULL,
    SemesterID Udt.SurrogateKeyInt NOT NULL,
    SectionNumber Udt.SectionNumber NOT NULL,
    Enrollment Udt.Enrollment NULL,
    EnrollmentLimit Udt.EnrollmentLimit NULL,
    ClassTime NVARCHAR(20) NOT NULL,  
    DateAdded Udt.DateAdded NOT NULL,
    DateOfLastUpdate Udt.DateOfLastUpdate NOT NULL,
    CONSTRAINT PK_Class PRIMARY KEY CLUSTERED (ClassID)
)
