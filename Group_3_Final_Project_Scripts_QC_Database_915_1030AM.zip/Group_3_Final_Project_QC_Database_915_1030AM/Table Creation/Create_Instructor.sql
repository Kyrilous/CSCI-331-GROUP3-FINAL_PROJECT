CREATE TABLE Production.Instructor
(
    InstructorID Udt.SurrogateKeyInt IDENTITY(1,1) NOT NULL,
    FirstName Udt.FirstName NOT NULL,
    LastName Udt.LastName NOT NULL,
    DepartmentID Udt.SurrogateKeyInt NOT NULL,
    DateAdded Udt.DateAdded NOT NULL,
    DateOfLastUpdate Udt.DateOfLastUpdate NOT NULL,
    CONSTRAINT PK_Instructor PRIMARY KEY CLUSTERED (InstructorID)
)
