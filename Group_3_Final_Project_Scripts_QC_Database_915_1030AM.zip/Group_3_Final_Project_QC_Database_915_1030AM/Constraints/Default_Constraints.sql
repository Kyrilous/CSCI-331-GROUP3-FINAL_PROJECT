ALTER TABLE Production.BuildingLocation
    ADD CONSTRAINT DF_BuildingLocation_DateAdded
        DEFAULT (SYSDATETIME()) FOR DateAdded

ALTER TABLE Production.BuildingLocation
    ADD CONSTRAINT DF_BuildingLocation_DateOfLastUpdate
        DEFAULT (SYSDATETIME()) FOR DateOfLastUpdate

ALTER TABLE Production.RoomLocation
    ADD CONSTRAINT DF_RoomLocation_DateAdded
        DEFAULT (SYSDATETIME()) FOR DateAdded

ALTER TABLE Production.RoomLocation
    ADD CONSTRAINT DF_RoomLocation_DateOfLastUpdate
        DEFAULT (SYSDATETIME()) FOR DateOfLastUpdate

ALTER TABLE Production.Department
    ADD CONSTRAINT DF_Department_DateAdded
        DEFAULT (SYSDATETIME()) FOR DateAdded

ALTER TABLE Production.Department
    ADD CONSTRAINT DF_Department_DateOfLastUpdate
        DEFAULT (SYSDATETIME()) FOR DateOfLastUpdate

ALTER TABLE Production.Course
    ADD CONSTRAINT DF_Course_DateAdded
        DEFAULT (SYSDATETIME()) FOR DateAdded

ALTER TABLE Production.Course
    ADD CONSTRAINT DF_Course_DateOfLastUpdate
        DEFAULT (SYSDATETIME()) FOR DateOfLastUpdate

ALTER TABLE Production.Instructor
    ADD CONSTRAINT DF_Instructor_DateAdded
        DEFAULT (SYSDATETIME()) FOR DateAdded

ALTER TABLE Production.Instructor
    ADD CONSTRAINT DF_Instructor_DateOfLastUpdate
        DEFAULT (SYSDATETIME()) FOR DateOfLastUpdate

ALTER TABLE Production.ModeOfInstruction
    ADD CONSTRAINT DF_ModeOfInstruction_DateAdded
        DEFAULT (SYSDATETIME()) FOR DateAdded

ALTER TABLE Production.ModeOfInstruction
    ADD CONSTRAINT DF_ModeOfInstruction_DateOfLastUpdate
        DEFAULT (SYSDATETIME()) FOR DateOfLastUpdate

ALTER TABLE Production.Semester
    ADD CONSTRAINT DF_Semester_DateAdded
        DEFAULT (SYSDATETIME()) FOR DateAdded

ALTER TABLE Production.Semester
    ADD CONSTRAINT DF_Semester_DateOfLastUpdate
        DEFAULT (SYSDATETIME()) FOR DateOfLastUpdate

-- Default class time if it's missing
ALTER TABLE Production.Class
    ADD CONSTRAINT DF_Class_ClassTime_Default
        DEFAULT ('00:00') FOR ClassTime

ALTER TABLE Production.Class
    ADD CONSTRAINT DF_Class_DateAdded
        DEFAULT (SYSDATETIME()) FOR DateAdded

ALTER TABLE Production.Class
    ADD CONSTRAINT DF_Class_DateOfLastUpdate
        DEFAULT (SYSDATETIME()) FOR DateOfLastUpdate

