-- Course belongs to a Department
ALTER TABLE Production.Course
    ADD CONSTRAINT FK_Course_Department
        FOREIGN KEY (DepartmentID)
        REFERENCES Production.Department (DepartmentID)

-- Instructor belongs to a Department
ALTER TABLE Production.Instructor
    ADD CONSTRAINT FK_Instructor_Department
        FOREIGN KEY (DepartmentID)
        REFERENCES Production.Department (DepartmentID)

-- Room belongs to a Building
ALTER TABLE Production.RoomLocation
    ADD CONSTRAINT FK_RoomLocation_Building
        FOREIGN KEY (BuildingID)
        REFERENCES Production.BuildingLocation (BuildingID)

-- Class references Course
ALTER TABLE Production.Class
    ADD CONSTRAINT FK_Class_Course
        FOREIGN KEY (CourseID)
        REFERENCES Production.Course (CourseID)

-- Class references Instructor
ALTER TABLE Production.Class
    ADD CONSTRAINT FK_Class_Instructor
        FOREIGN KEY (InstructorID)
        REFERENCES Production.Instructor (InstructorID)

-- Class references ModeOfInstruction
ALTER TABLE Production.Class
    ADD CONSTRAINT FK_Class_Mode
        FOREIGN KEY (ModeID)
        REFERENCES Production.ModeOfInstruction (ModeID)

-- Class references RoomLocation
ALTER TABLE Production.Class
    ADD CONSTRAINT FK_Class_Room
        FOREIGN KEY (RoomID)
        REFERENCES Production.RoomLocation (RoomID)

-- Class references Semester
ALTER TABLE Production.Class
    ADD CONSTRAINT FK_Class_Semester
        FOREIGN KEY (SemesterID)
        REFERENCES Production.Semester (SemesterID)
