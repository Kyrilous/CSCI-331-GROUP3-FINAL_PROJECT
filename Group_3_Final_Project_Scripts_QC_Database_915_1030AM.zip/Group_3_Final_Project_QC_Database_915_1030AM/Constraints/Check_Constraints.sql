-- Building name can't be blank
ALTER TABLE Production.BuildingLocation
    ADD CONSTRAINT CK_BuildingLocation_NotBlank
        CHECK (LEN(BuildingName) > 0)

-- Department name not blank
ALTER TABLE Production.Department
    ADD CONSTRAINT CK_Department_Name_NotBlank
        CHECK (LEN(DepartmentName) > 0)

-- Department code only uppercase letters/digits
ALTER TABLE Production.Department
    ADD CONSTRAINT CK_Department_DepartmentCode_Uppercase
        CHECK (DepartmentCode NOT LIKE '%[^A-Z0-9]%')

-- Course course number not blank
ALTER TABLE Production.Course
    ADD CONSTRAINT CK_Course_CourseNumber_NotBlank
        CHECK (LEN(CourseNumber) > 0)

-- Course credits must be > 0
ALTER TABLE Production.Course
    ADD CONSTRAINT CK_Course_Credits_Positive
        CHECK (Credits > 0)

-- Instructor first/last name not blank
ALTER TABLE Production.Instructor
    ADD CONSTRAINT CK_Instructor_FirstName_NotBlank
        CHECK (LEN(FirstName) > 0)

ALTER TABLE Production.Instructor
    ADD CONSTRAINT CK_Instructor_LastName_NotBlank
        CHECK (LEN(LastName) > 0)

-- Mode name not blank
ALTER TABLE Production.ModeOfInstruction
    ADD CONSTRAINT CK_ModeOfInstruction_NotBlank
        CHECK (LEN(ModeName) > 0)

-- Room room number not blank
ALTER TABLE Production.RoomLocation
    ADD CONSTRAINT CK_RoomLocation_RoomNumber_NotBlank
        CHECK (LEN(RoomNumber) > 0)

-- Class enrollment and limit rules
ALTER TABLE Production.Class
    ADD CONSTRAINT CK_Class_Enrollment_Positive
        CHECK (Enrollment >= 0)

ALTER TABLE Production.Class
    ADD CONSTRAINT CK_Class_EnrollmentLimit_Positive
        CHECK (EnrollmentLimit >= 0)

ALTER TABLE Production.Class
    ADD CONSTRAINT CK_Class_Enrollment_WithinLimit
        CHECK ( Enrollment IS NULL  OR EnrollmentLimit IS NULL OR Enrollment <= EnrollmentLimit )
