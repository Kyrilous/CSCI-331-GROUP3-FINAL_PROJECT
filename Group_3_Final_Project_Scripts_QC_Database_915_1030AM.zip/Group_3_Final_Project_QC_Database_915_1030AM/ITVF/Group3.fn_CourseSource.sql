-- Extract courses from the upload file
CREATE FUNCTION Group3.fn_CourseSource()
RETURNS TABLE
AS
RETURN
(
    SELECT DISTINCT
        UPPER(LEFT(Code, CHARINDEX(' ', Code + ' ') - 1)) AS DepartmentCode,

        LTRIM(RTRIM(SUBSTRING(Code,
            CHARINDEX(' ', Code + ' ') + 1, 10))) AS CourseNumber,

        LTRIM(RTRIM(Description)) AS CourseTitle
    FROM Uploadfile.CurrentSemesterCourseOfferings
    WHERE Code IS NOT NULL AND Description IS NOT NULL
)
