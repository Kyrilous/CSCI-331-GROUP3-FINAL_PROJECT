-- Returns the distinct modes of instruction
CREATE FUNCTION Group3.fn_ModeSource()
RETURNS TABLE
AS
RETURN
(
    SELECT DISTINCT
        LTRIM(RTRIM([Mode of Instruction])) AS ModeName
    FROM Uploadfile.CurrentSemesterCourseOfferings
    WHERE [Mode of Instruction] IS NOT NULL
          AND LTRIM(RTRIM([Mode of Instruction])) <> ''
);
