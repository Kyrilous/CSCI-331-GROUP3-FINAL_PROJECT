-- Extract distinct room numbers paired with buildings
CREATE FUNCTION Group3.fn_RoomSource()
RETURNS TABLE
AS
RETURN
(
    SELECT DISTINCT
        UPPER(LEFT(Location, CHARINDEX(' ', Location + ' ') - 1)) AS BuildingName,
        SUBSTRING(Location, CHARINDEX(' ', Location + ' ') + 1, 50) AS RoomNumber
    FROM Uploadfile.CurrentSemesterCourseOfferings
    WHERE Location IS NOT NULL AND Location LIKE '% %'
);
