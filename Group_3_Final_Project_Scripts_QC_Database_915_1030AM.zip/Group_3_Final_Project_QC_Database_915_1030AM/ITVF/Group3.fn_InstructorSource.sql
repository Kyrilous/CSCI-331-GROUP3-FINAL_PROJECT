-- Parse instructor full names into first and last names
CREATE FUNCTION Group3.fn_InstructorSource()
RETURNS TABLE
AS
RETURN
(
    SELECT DISTINCT
        LTRIM(RTRIM(SUBSTRING(Instructor,
            CHARINDEX(',', Instructor + ',') + 1, 200))) AS FirstName,

        LTRIM(RTRIM(LEFT(Instructor,
            CHARINDEX(',', Instructor + ',') - 1))) AS LastName,

        UPPER(LEFT(Code, CHARINDEX(' ', Code + ' ') - 1)) AS DepartmentCode
    FROM Uploadfile.CurrentSemesterCourseOfferings
    WHERE Instructor IS NOT NULL AND Instructor <> ''
)
