-- Returns unique semester names from the upload file
CREATE FUNCTION Group3.fn_SemesterSource()
RETURNS TABLE
AS
RETURN
(
    SELECT DISTINCT
        LTRIM(RTRIM(Semester)) AS SemesterName
    FROM Uploadfile.CurrentSemesterCourseOfferings
    WHERE Semester IS NOT NULL AND LTRIM(RTRIM(Semester)) <> ''
)
