-- Produces cleaned class data from the raw upload
CREATE FUNCTION Group3.fn_ClassSource()
RETURNS TABLE
AS
RETURN
(
    SELECT
        -- Course fields 
        UPPER(LEFT(Code, CHARINDEX(' ', Code + ' ') - 1)) AS DepartmentCode,
        LTRIM(RTRIM(SUBSTRING(Code,
            CHARINDEX(' ', Code + ' ') + 1, 10))) AS CourseNumber,

        -- Instructor fields
        LTRIM(RTRIM(SUBSTRING(Instructor,
            CHARINDEX(',', Instructor + ',') + 1, 200))) AS FirstName,
        LTRIM(RTRIM(LEFT(Instructor,
            CHARINDEX(',', Instructor + ',') - 1))) AS LastName,

        -- Building/Room fields
        UPPER(LEFT(Location, CHARINDEX(' ', Location + ' ') - 1)) AS BuildingName,
        SUBSTRING(Location, CHARINDEX(' ', Location + ' ') + 1, 30) AS RoomNumber,

        -- Semester
        LTRIM(RTRIM(Semester)) AS SemesterName,

        -- Section information
        LTRIM(RTRIM(Sec)) AS SectionNumber,

        -- Mode
        LTRIM(RTRIM([Mode of Instruction])) AS ModeName,

        -- Enrollment numbers
        CASE WHEN TRY_CAST(Enrolled AS INT) IS NULL THEN 0 ELSE TRY_CAST(Enrolled AS INT) END AS Enrollment,

        CASE WHEN TRY_CAST([Limit] AS INT) IS NULL THEN 0 ELSE TRY_CAST([Limit] AS INT) END AS EnrollmentLimit,

        -- Class time (string)
        LTRIM(RTRIM(Time)) AS ClassTime
    FROM Uploadfile.CurrentSemesterCourseOfferings
)
