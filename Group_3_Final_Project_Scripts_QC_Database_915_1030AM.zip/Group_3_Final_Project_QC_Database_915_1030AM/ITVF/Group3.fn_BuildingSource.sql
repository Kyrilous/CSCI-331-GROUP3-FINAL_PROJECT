-- Extract distinct building names from the Location column
CREATE FUNCTION Group3.fn_BuildingSource()
RETURNS TABLE
AS
RETURN
(
    SELECT DISTINCT
        UPPER(LEFT(Location, CHARINDEX(' ', Location + ' ') - 1)) AS BuildingName
    FROM Uploadfile.CurrentSemesterCourseOfferings
    WHERE Location IS NOT NULL AND LTRIM(RTRIM(Location)) <> ''
)
