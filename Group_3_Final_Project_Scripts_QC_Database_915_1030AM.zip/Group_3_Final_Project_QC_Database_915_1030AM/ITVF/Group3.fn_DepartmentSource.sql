-- Returns unique departments from the raw upload
CREATE FUNCTION Group3.fn_DepartmentSource()
RETURNS TABLE
AS
RETURN
(
    SELECT DISTINCT
        UPPER(LEFT(Code, CHARINDEX(' ', Code + ' ') - 1)) AS DepartmentCode,
        UPPER(LEFT(Code, CHARINDEX(' ', Code + ' ') - 1)) AS DepartmentName
    FROM Uploadfile.CurrentSemesterCourseOfferings
    WHERE Code IS NOT NULL AND Code <> ''
)
