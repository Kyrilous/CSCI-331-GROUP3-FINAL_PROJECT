-- Schema creation script

CREATE SCHEMA Nasr
GO

CREATE SCHEMA Production
GO

CREATE SCHEMA Udt
GO

CREATE SCHEMA Utils
GO

CREATE SCHEMA Group3
GO

CREATE SCHEMA Group3Project3
GO
